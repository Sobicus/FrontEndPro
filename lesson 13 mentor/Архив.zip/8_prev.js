// Напишите функцию insertDash (num), который будет вставлять тире ('-')
// между каждыми двумя нечетными цифрами в num. Например: если число 454379, вывод должен быть 4543-7-9.
// Не считайте ноль как нечетное число.
//Обратите внимание, что число всегда будет неотрицательным (> = 0)
// 454379
function insertDash(num) {
	const str = "" + num;
	let result = "";

	for (let i = 0; i < str.length - 1; i++) {
		result += str[i];
		if(str[i] % 2 !== 0 && str[i+1] % 2 !== 0) {
			result += "-";
		}
	}
	result += str[str.length - 1];
	return result;
}

console.log(insertDash("454379"));


 // ----------------------

function insertDashRegex(str) {
	return str.replace(/([13579])(?=[13579])/g, "$1-")
}
console.log(insertDashRegex("454379"));


// через регулярку

