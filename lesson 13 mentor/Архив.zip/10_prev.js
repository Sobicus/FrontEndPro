//Дана строка цифр, замените любую цифру меньше 5 на «0», а любую цифру от 5 и больше на «1».
// Необходимо вернуть полученную строку.

// 13474 -> 00010


function transform(str) {
	let result = "";

	for (let i = 0; i < str.length; i++) {
		if (+str[i] < 5) {
			result += "0";
		} else {
			result += "1";
		}
	}
	return result;
}

console.log(transform("134749012987987"));

function transformReg(str) {
	// return str.replace(/[1-4]/g, "0").replace(/[5-9]/g, "1");
	return str.replace(/\d/g, (a) => +a < 5 ? "0" : "1");
}
console.log(transformReg("134749012987987"));

// -------------------


