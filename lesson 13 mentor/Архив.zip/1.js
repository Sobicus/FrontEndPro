
// проверить емеил на валидность


console.log(isEmailValid("saas@sdf.fg"));
console.log(isEmailValid("saassdf.fg"));
console.log(isEmailValid("saass@df.fgas"));

function isEmailValid(str) {
	return /^\w+@\w+\.\w{2,3}$/.test(str);
}
